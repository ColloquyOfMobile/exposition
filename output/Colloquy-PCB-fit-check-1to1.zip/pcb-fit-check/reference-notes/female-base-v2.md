# Female base v2 — directly mounted GF1002 amplifier

Open `female-base-v2.kicad_pro` in KiCad 9. The project includes a schematic,
routed two-layer PCB, assembled STEP model, top/underside previews, BOM and
CAD verification reports. The original `../female base/` project is preserved.

The **amplifier module itself** mounts on this PCB. Thomas's green perfboard,
its JST sockets and blue terminal are absent. **Specification (revision D,
2026-10-19): the module plugs into a 1 × 11 female socket on this board
through male header pins on its contact row.** The socket carries every
connection, and two insulating supports hold the module level. The schematic
and board now implement **revision D**: M1 is the electrical socket, with no
JA1 hookup pads or hand wires. This is an engineering prototype based on the approximate GF1002
reference, not a physically qualified production release.

## Revision D: plug-in on header pins (2026-10-19)

The module plugs in the way the DFRobot modules plug into the analyser
carrier: male header pins on the module, a female socket on the board. It
comes out without desoldering. The contact positions come from
`../shields/gf1002-reference/README.md`.

**Socket.** One 1 × 11 female socket, 2.54 mm pitch, vertical
(`Connector_PinSocket_2.54mm:PinSocket_1x11_P2.54mm_Vertical`), placed on
the module's contact row. Its centre line is at X = 49.55 mm (module origin
+ 18.55 mm, the reference model's contact X). Pin 1 is at the pot end at
Y = 56.2 mm, and pin n is at 56.2 + 2.54·(n − 1), so pin 11 is at 81.6 mm.
Solder all eleven socket pins for strength; positions 4 and 7 have no
module pin.

**Module.** Fit straight 2.54 mm male headers through positions 1–3 (1 × 3),
5–6 (1 × 2) and 8–11 (1 × 4), plastic underneath. Solder them while they
sit in the socket, so they line up with it. Thomas's carriers already have
pins in these holes, so standard header pins should pass; check one module.

| Socket pin | Module contact | Net |
|---:|---|---|
| 1 | input R | `AMP_INPUT` |
| 2 | input G | `AUDIO_RETURN` |
| 3 | input L | none |
| 4 | no contact | none |
| 5 | power + | `5V` |
| 6 | power − | `GND` |
| 7 | no contact | none |
| 8, 9 | LOUT pair | none |
| 10, 11 | ROUT pair | `AMP_OUT_P`, `AMP_OUT_N`, to J6 |

The photo doesn't show which of pins 10 and 11 is ROUT+. Read it on the
module and record it; J6 pin 1 is ROUT+. Swapping them only inverts the
speaker's phase. No output contact, ROUT or LOUT, is ever connected to
ground.

**Height.** The shields use the same stack, a 2.5 mm male header plastic on
an 8.5 mm female socket (`../shields/ASSEMBLY.md`). It puts the module's
underside about **11 mm** above the board, 8 mm higher than revision C's
3 mm. The pot then stands about **28 mm** above the board, and the shaft
rises by the same 8 mm. Check both inside the female body before ordering.
Any part under the module must be lower than the socket body.

**Supports.** H1 (shaft edge, (28.5, 74.5)) and H2 (short end, (41.1, 87.5))
stay where they are. They become supports at the stack height, measured on
the header and socket actually bought. The socket fixes where the module
sits, so the supports' seats must allow ±0.5 mm, the photo's uncertainty in
the row's offset. Their lips may stay, but the module must come out after
loosening them. H1 takes the push when the knob is turned or pressed, so
the knob doesn't lever the socket.

**Removed from revision C.** JA1 and its six wires; the instruction to cut
the pin tails flush; the rule area that keeps pads out of the contact strip.
The socket sits in that strip now, and no other part or via may.

**Schematic and checks.** The GF1002 becomes a 1 × 11 connector symbol
with the nets above, and no-connect flags on pins 3, 4, 7, 8 and 9. ERC and
schematic/PCB parity then cover the module's connections. `verify_boards.py`
checks the socket's position against the reference model's contact row,
and every pin's net.

### Routing rules

1. **Class-D output.** The ROUT pair (pins 10, 11) runs to J6 side by side,
   as short as the layout allows, in the Power class as now. Thomas's
   document asks for short speaker leads: the output is a ~250 kHz PWM
   signal with sharp edges and high currents.
2. **Keep the output away from every input.** Put ground, as a pour or a
   track, between the output pair and `AMP_INPUT`, `LINE_IN`,
   `AUDIO_RETURN`, the microphone line and the photosensor lines. They may
   cross only at right angles, never run alongside. Revision C on this
   board runs the output 20.7 mm alongside `AMP_INPUT`, within 2 mm, on
   the same layer.
3. **Input.** `LINE_IN` and `AUDIO_RETURN` run together from J7 to the
   divider. R1 and R2 sit beside socket pins 1 and 2, so `AMP_INPUT` is
   only a few millimetres long.
4. **Supply.** `5V` and `GND` reach pins 5 and 6 in the Power class. C2
   (100 nF) sits directly beside pins 5 and 6, with C1 (220 µF) close by;
   revision C has them about 30 mm away. C2 may sit under the module if it
   is lower than the socket body.
5. **The grounds meet only on the module.** `AUDIO_RETURN` goes to pin 2
   only and `GND` to pin 6; nothing else on this board joins them. Check
   with a meter that the module's G and − contacts are joined on the module
   itself (expected). If they are not, stop and decide before ordering.
6. **Unused contacts.** Pins 3, 4, 7, 8 and 9 have no net.

### Before ordering

Measure one module:
- the row's offset from its edge and the first contact's distance from the
  pot end (these place the module against H1, H2 and the outline; the
  pitch is the socket's);
- that a header pin passes its holes;
- the stack height of the chosen header and socket;
- the pot overhang, and the knob's height inside the body.

Then plug the module into a socket on a 1:1 print of the revision D board.
`../shields/RELEASE_REVIEW.md` F8 stays open until then.

## Implemented layout and mechanical interface

The original 50 × 80 mm artwork outline, cutouts and exact DSUB pad/drill
positions are retained. Original connector pin orders are unchanged.
The module uses the same photo-derived 20.2 × 30 mm conservative envelope.
H1 and H2 retain their specified PCB hole positions. Their new insulating
support models have an 11 mm seat, a 1.8 mm module slot, short removable
retaining lips and a 3.2 × 2.2 mm screw slot for ±0.5 mm adjustment.
Select insulating M2 hardware and measure the actual socket/header stack
before printing/fitting the supports. No amplifier PCB drilling is required.

The socket's 8.5 mm body and nominal 2.5 mm header plastic put the module
underside at 11 mm and its PCB top at 12.6 mm above the carrier. Pot height
is approximately 28 mm; the shaft overhang is approximately 16 mm beyond
the board's left edge. Confirm both against the installed body.
Only low-profile divider/bypass parts sit under the module. The tall C1
reservoir stays outside its envelope. All eleven socket pins are soldered;
module male headers populate positions 1–3, 5–6 and 8–11 only.

The socket alone occupies the contact strip. Native rule areas forbid
vias there; independent checks reject other components or pads in it.
The old pad-exclusion rule and flush-cut-pin instruction are removed.
To remove the amplifier, loosen the support lips and unplug the headers.

R1/R2 sit beside socket pins 1/2. C2 is less than 5 mm from both supply
contacts, with C1 nearby. Main supply and speaker routes use the 0.8 mm
Power width; short 0.25 mm necks enter the 0603 bypass pads. The input
pair approaches on back copper, with AMP_INPUT confined to the divider
and socket. A front grounded guard and ground pours separate the lower
output region from the input and sensor region. No output is grounded.

Speaker paths are 18.153/19.191 mm; the complete AMP_INPUT branch is 7.265 mm.
Independent checks find no parallel sensitive runs within 2.5 mm and no
output/input or sensor crossings in projection, including across layers.
Reports record geometry and source hashes in `reports/validation.json`.
Native ERC/DRC/unconnected/parity are all zero. These CAD checks do not
establish noise performance, current capacity or physical fit.

Inspect the updated STEP, previews and 1:1 templates before the mandatory
real-module fit, stack-height, ground-bond and output-polarity checks.

## Audio and power

The DSUB J7 retains its exact physical pinout, with this change in function:

| J7 pin | v2 function |
|---|---|
| 12 | LINE_IN, formerly remote amplifier speaker + |
| 4 | AUDIO_RETURN, formerly remote amplifier speaker − |
| 15 | 5 V supply, unchanged |
| 8 and shell pads | Supply GND, unchanged |

**The rack must supply line-level audio and audio return on the former
speaker pair before this board is connected.** The original rack class-D
speaker output must be disconnected from that pair. J6 now connects only
to the local GF1002 output, never directly to J7.

R1=22K and R2=3K3 reproduce Thomas's input divider. The divider's bottom and
the module's input-ground wire use AUDIO_RETURN. The module supply-ground
wire uses GND. These are separate PCB nets; the amplifier's internal ground
connections and resulting return currents require bench verification.
Both copper faces have local GND pours, with full pad connections; isolated
islands are removed. AUDIO_RETURN has its own routed connection.

M1 is the 11-pin plug-in socket. Its pin-to-net table is given above (on
the male board it is the same table as the female board). Pins 3, 4, 7,
8 and 9 have no connections and have schematic no-connect flags.
Pin 10 is provisionally ROUT+ to J6.1, pin 11 ROUT− to J6.2. Confirm the
actual module polarity before ordering; the source photo cannot establish it.

The GF1002 branch is connected to **5 V only**. The existing 12 V net serves
the servo and does not reach M1. A 220 µF/10 V local reservoir and 100 nF
bypass are fitted; reservoir sizing is provisional. This does not establish
the GF1002's supply rating or the shared harness's current capacity. Check
rail sag, clipping and noise with the actual module, speaker and harness.

## Rebuild and verification

Shared scripts in `scripts/` regenerate this project and `../male static v2/`:

```powershell
& 'C:/Program Files/FreeCAD 1.0/bin/python.exe' 'CAD/KiCad/female base v2/scripts/build_clamps.py'
& 'C:/Program Files/KiCad/9.0/bin/python.exe' 'CAD/KiCad/female base v2/scripts/build_boards.py'
& 'C:/Program Files/KiCad/9.0/bin/python.exe' 'CAD/KiCad/female base v2/scripts/route_boards.py'
& 'C:/Program Files/KiCad/9.0/bin/python.exe' 'CAD/KiCad/female base v2/scripts/finish_boards.py'
& './CAD/KiCad/female base v2/scripts/export_boards.ps1'
& 'C:/Program Files/KiCad/9.0/bin/python.exe' 'CAD/KiCad/female base v2/scripts/verify_boards.py'
```

Routing uses the existing local Freerouting 2.4.1 jar and Android Studio Java
paths declared in the script. Rebuilding replaces the v2 schematic and board.
`*-placed.kicad_pcb` is the unrouted checkpoint. `circuit.json` records the
circuit and positions; `reports/` contains ERC, DRC, native schematic parity,
netlist and SVG exports. No fabrication package is released at this stage.

Validation covers native ERC/DRC, completed routing, schematic/PCB parity,
unchanged original artwork cutouts and DSUB pad positions, original connector
pin order/drills, 5 V amplifier wiring and local model resolution. STEP
assemblies were reopened and checked; top and underside previews inspected.
Physical fit, electrical performance and installation clearances remain
unverified. The schematic models the GF1002 as an 11-pin socket, so ERC and native
parity cover every carrier connection and no-connect. They do not validate
the module's undocumented internal circuit or its physical contact positions.

Revision D validation (2026-10-19): native ERC/DRC/unconnected/parity 0/0/0/0;
independent socket, routing, decoupling, support, harness and original-geometry
checks pass (`reports/validation.json`). The full repository suite passes
1,796 tests. STEP assemblies reopen with valid geometry; previews inspected.

Sources: original repository body-board designs; Thomas's documentation
and the photo-derived `../shields/gf1002-reference/` model. Generic KiCad
library models retain their CC BY-SA 4.0 license with the library exception.

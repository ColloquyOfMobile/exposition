COLLOQUY PCB PAPER FIT CHECK - 15 OCTOBER 2026

UPDATED PACK: 14 distinct PCB layouts, including the new Rev C microphone
holder and both female/male v2 body PCBs. Print the microphone-flex sheet
for the new 32 x 62 mm holder: its two transverse slots are 12 x 5.5 mm,
50 mm apart. The prior 20 x 62 mm microphone sheet is labelled REV B
COMPARISON. They are alternative revisions, not two boards to stack together.
Rev C has three alternative sockets and supports for exactly ONE microphone
module facing left, right or upward. All three choices use the SAME PCB
outline and holes; no duplicate templates are needed for the orientations.
Rev-C-microphone-positions.png shows the three choices. Rev C is a checked
engineering prototype; confirm socket/module/support fit on physical parts.

START WITH 01-cut-and-fit-A4-actual-size.pdf.
Print on A4 at ACTUAL SIZE / 100%. Disable Fit, Shrink, booklet and any
borderless enlargement. Measure BOTH the 50 mm horizontal bar and the 10 mm
vertical bar before cutting. A PDF viewer's on-screen zoom is not print scale.
Cut on the centre of the board outline, not component outlines or copper pads.
White centres in pads show actual drill geometry, including elongated slots.
Thin black perimeters make every footprint drill/slot visible on white paper;
cut/punch along their centre lines. CSV pad angles preserve rotated slots.

LARGE BOARDS
The 210 x 297 mm backplane cannot fit within ordinary A4 printable margins.
Its four A4 tiles overlap by 10 mm. Match the repeated grey crosses and the
actual board features, trim one overlapping margin, and tape together before
cutting. Row/column and crop origins identify the tiles. Do not join the page
edges directly. Other boards are one page each.
02-cut-and-fit-A3-whole-boards.pdf has one complete board per A3 sheet.
Use A3 paper at 100%; printing that file on A4 would shrink the templates.

CONNECTIONS
03-connections-front-and-back-A4.pdf shows the existing outer copper, pads,
drills, silkscreen and contours at 1:1. Front is viewed from above; BACK is
mirrored to represent looking directly at the underside. Do not overlay a
back sheet on a top sheet without turning it over. Internal copper layers
are not shown. Cut-and-fit sheets omit traces/fills to keep geometry legible.
Reference-only models have no reconstructed copper routing; their connection
views show available pads and legends, not a verified electrical circuit.
contacts/*.csv records every source footprint pad, pin number, existing net,
drill/slot size and centre coordinates. Coordinate origin is the top-left
outline extent; X right, Y down in the TOP view. Empty nets stay empty.

BOARDS / NUMBER OF PAPER COPIES FOR THE SHIELD ASSEMBLY
backplane: 1; teensy-adapter: 1; voice-thomas: 5 (same physical board for all
five voices); analyser-carrier: 1; microphone-flex Rev C: 6 (five plus spare),
or the earlier microphone Rev B if deliberately building that revision.
female-base-v2: 3; male-static-v2: 2. These body PCB templates include the
existing amplifier clamp holes and connector pads. The amplifier itself
is included separately as gf1002-reference; paper shows its planar geometry.
References: Arduino Mega 2560 Rev3e, Teensy 4.1, modified DFRobot module
(five for the Mega analyser carrier), MAX9814 microphone module (five plus
spare), GF1002 amplifier module, and Thomas's amplifier carrier.
Five shield types, the alternative Rev C holder, both current v2 body PCBs
and six reference boards are included (14 distinct layouts). Obsolete boards,
unrouted checkpoints and older body/control-board designs are not included.

HOW TO CHECK
Cut the boards, open the mounting holes/slots and connector pin centres,
and compare against real boards/connectors/spacers. Check every mounting and
mating contact, especially Mega versus Teensy adapter and analyser modules.
Paper checks XY only. It does not establish connector seating, spacer height,
component height or cable clearance. Do not use these as etching masks.

REFERENCE ACCURACY
Mega: manufacturer Rev3e planar geometry; check the actual board/clone.
Teensy: imported community geometry; actual hardware revisions can differ.
DFRobot: 22 x 34 mm user-corrected outline; headers and mounting positions
remain photo-derived. Retained mounting holes break through the side edges.
MAX9814: original Adafruit geometry; the violet clone may differ.
GF1002 and Thomas amplifier carrier: photo-estimated outlines, contacts and
mounting holes. Unconfirmed dimensions are not made exact by printing 1:1.
See reference-notes/ for the original board descriptions and retained licenses.

CONTENTS / VALIDATION
Three vector PDFs, original-scale SVG plots (including separate contours),
pad-coordinate CSVs, source SHA-256 manifest and print scale/tile validation.
Generated directly from the current routed KiCad files and reference PCBs.
Original CAD files were not modified. Board outline dimensions exclude stroke
width. The SVG millimetre dimensions are explicitly preserved in the PDFs;
all crop/tile placements have equal source and destination sizes.
Source hashes let this pack be checked against later PCB revisions.

ATTRIBUTION
Arduino Mega reference: Arduino S.r.l., CC BY-SA 4.0.
MAX9814 reference: Limor Fried/Ladyada for Adafruit Industries, CC BY-SA 3.0.
Teensy reference: Zack Kummer / XenGi Teensy library, MIT; see retained license.
KiCad library graphics: CC BY-SA 4.0 with the KiCad library exception.
Original reference board notes retain further sources and qualifications.

# analyser-carrier — manufacturer handoff

Bare-PCB fabrication files are at the ZIP root: Gerber X2 copper, solder mask,
silkscreen and board outline, plus separate PTH and NPTH Excellon drills.
Use Edge.Cuts as the finished outline. Drill slots use routed Excellon commands;
retain them as slots, not round holes. Do not mirror any supplied file.
Gerbers, drills and placement CSVs use the same absolute board origin and mm.

Layer count: 2. Top-to-bottom copper: F.Cu, B.Cu.
Finished board thickness: 1.6 mm. Supply rigid FR-4 boards.
Copper weight, surface finish, mask colour and the manufacturer's dielectric
stack-up are not specified here: confirm these quotation options before ordering.
No controlled-impedance fabrication requirement is declared in this package.
Quantity and panelisation are order choices; one unpanelised board is supplied.

Assembly policy: order bare boards; fit every part by hand.
Analyser carrier: no SMD parts to place; fit sockets and modified modules by hand.

assembly/ contains BOM, an all-component placement reference, top/bottom
assembly drawings, drill maps, and project assembly notes. Outsourced boards
also include a front SMD placement CSV and front stencil paste Gerber.
These are assembly references, not a fully procurement-qualified PCBA order:
some BOM MPNs are blank or descriptive, and purchased modules/composite socket
footprints require manual interpretation. Confirm exact parts, DNP/variant
population and assembler rotation conventions before machine assembly.
Do not interpret a module-outline footprint as a single pick-and-place part.
For voice-thomas choose ONE intended variant BOM; variants share the same PCB.

This is the current engineering prototype artwork. Read the enclosed project
notes for connector conversion, keying, insulation and fit checks. In particular,
the analyser carrier's module fit remains unverified physically. DRC checks
electrical/layout rules, not purchased-part fit or enclosure clearance.

Source: analyser-carrier.kicad_pcb
Source SHA-256: 60865066594c376e08733a0f9be754a277abc0163d77eac56159fb4cfb8b6f1d
Freshly refilled export: checked with KiCad 9.0.7.
DRC errors: 0; warnings: 0;
unconnected items: 0. Full report: checks/drc.json.
The source KiCad PCB was not modified by packaging.

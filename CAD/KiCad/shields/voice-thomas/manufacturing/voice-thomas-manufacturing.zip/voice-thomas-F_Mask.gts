%TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*%
%TF.CreationDate,2026-10-13T11:52:38+02:00*%
%TF.ProjectId,voice-thomas,766f6963-652d-4746-986f-6d61732e6b69,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-10-13 11:52:38*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.200000X0.275000X-0.200000X0.275000X0.200000X-0.275000X0.200000X-0.275000X-0.200000X0*%
%ADD11R,1.700000X1.700000*%
%ADD12C,1.500000*%
%ADD13C,1.600000*%
%ADD14C,3.200000*%
%ADD15C,1.800000*%
%ADD16O,1.700000X1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,R3*%
X57000000Y-66825000D03*
X57000000Y-65175000D03*
%TD*%
D11*
%TO.C,TP4*%
X65000000Y-89000000D03*
%TD*%
D12*
%TO.C,TP1*%
X53000000Y-86000000D03*
%TD*%
D13*
%TO.C,R1*%
X61000000Y-55000000D03*
X68620000Y-55000000D03*
%TD*%
D14*
%TO.C,H1*%
X74000000Y-84000000D03*
%TD*%
D15*
%TO.C,C2*%
X62000000Y-76000000D03*
X67000000Y-76000000D03*
%TD*%
D13*
%TO.C,R2*%
X61000000Y-60000000D03*
X68620000Y-60000000D03*
%TD*%
D15*
%TO.C,C1*%
X62000000Y-67000000D03*
X67000000Y-67000000D03*
%TD*%
D11*
%TO.C,TP5*%
X67540000Y-89000000D03*
%TD*%
%TO.C,JV1*%
X53000000Y-56000000D03*
D16*
X55540000Y-56000000D03*
X53000000Y-58540000D03*
X55540000Y-58540000D03*
X53000000Y-61080000D03*
%TD*%
M02*
